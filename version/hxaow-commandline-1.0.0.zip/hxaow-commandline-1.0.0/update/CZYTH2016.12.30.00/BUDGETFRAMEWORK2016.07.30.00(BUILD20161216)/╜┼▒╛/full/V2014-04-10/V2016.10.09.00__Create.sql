create table ydz_flyway_test1
(
name varchar2(100),
code varchar2(50)

);