

insert into ydz_flyway_test(name,code)values('ydztest','123');