

truncate table ydz_flyway_test;