

insert into ydz_flyway_test(name,code)values('太仓测试','123');