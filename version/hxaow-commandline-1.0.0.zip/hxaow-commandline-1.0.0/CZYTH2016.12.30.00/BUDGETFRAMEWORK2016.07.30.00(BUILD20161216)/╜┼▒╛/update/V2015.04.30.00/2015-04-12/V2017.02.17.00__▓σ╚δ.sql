

update ydz_flyway_test set name='123';