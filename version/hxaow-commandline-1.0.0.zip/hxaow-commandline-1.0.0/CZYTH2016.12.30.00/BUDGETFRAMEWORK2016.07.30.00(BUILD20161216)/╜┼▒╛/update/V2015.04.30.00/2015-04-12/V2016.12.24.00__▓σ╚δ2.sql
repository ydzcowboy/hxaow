

insert into ydz_flyway_test(name,code)values('ydz','001');