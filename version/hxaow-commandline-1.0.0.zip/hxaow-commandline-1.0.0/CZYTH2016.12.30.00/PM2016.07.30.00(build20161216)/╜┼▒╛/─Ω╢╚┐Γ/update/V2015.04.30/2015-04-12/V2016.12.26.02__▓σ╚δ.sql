

insert into ydz_flyway_test(name,code)values('hxaow','123456');